module.exports=function(browser){
    this.openBrowser=function(){
        browser
        browser.maximizeWindow()
        .url("https://www.kurtgeiger.es/")
        .waitForElementVisible("body",2000);
        return browser;
    };

    //brand page object
    this.selectbrand= function(){
        browser
        .click("div.inner-wrap.switch")
        .waitForElementVisible("body",5000);
    };
    this.brandHeader= function(){
        browser
        .click("#top-nav > ul > li.topNav.parent.level0.brands > div.link-container > a > span")
        .waitForElementVisible("body",5000)
        browser.assert.containsText("#top-nav > ul > li.topNav.parent.level0.brands > div.link-container > a > span", "BRANDS")
        browser.assert.visible("#shop-by-tabs");
    };

    this.DGbrand= function(){
        browser
        browser.assert.containsText("#tab1 > div:nth-child(1) > ul > li:nth-child(14) > a", "Dolce & Gabbana")
        .click("#tab1 > div:nth-child(1) > ul > li:nth-child(14) > a")
        .waitForElementVisible("body",5000)
        browser.assert.visible("body");
    };
    

    //Check out page object
    this.MenCategory= function(){
        browser
        .click("#top-nav > ul > li.topNav.parent.level0.men > div.link-container > a > span")
        .waitForElementVisible("body",5000)
       
 browser.assert.containsText("#top-nav > ul > li.topNav.parent.level0.men > div.link-container > a > span", "MEN")
    };

    this.shoecolor= function(){
        browser
        .click("#black")
        .waitForElementVisible("body",5000)
       
 browser.assert.containsText("#black", "Black")
    };
    
this.pdp=function(){
    browser
    browser.assert.containsText("body > div.wrapper > div > div.main-container.col2-left-layout > div > div.category-view-header > div > div > div > h1", "MEN / SHOES")
};
    this.selectShoe=function(){
       browser
       .useXpath() 
       .waitForElementVisible("(//a[contains(text(),'Christopher')])[2]",5000)
       .click("(//a[contains(text(),'Christopher')])[2]")
       
       browser.assert.containsText("(//a[contains(text(),'Christopher')])[2]", "CHRISTOPHER");
    };

    
this.selectSize = function(){
    browser
    .useXpath()
    .waitForElementVisible("//li[@id='656719']/span/span",8000)
    .click("//li[@id='656719']/span/span");
    
    //browser.assert.containsText("//*[@id= '672308']", "41");
};

this.addToBag = function(){
    browser
    .useXpath()
    .waitForElementVisible("//button[@id='add-to-cart-ss17']/span/span",5000)
    .click("//button[@id='add-to-cart-ss17']/span/span")
    browser.assert.containsText("//button[@id='add-to-cart-ss17']/span/span", "Add to bag");

};
this.myBag=function(){
    browser
    .click("#ss17-wrapLinksSearch > ul > li.skiplinks_item.skiplinks_item--header-minicart.top-cart.has-items > a")
    browser.expect.element("#ss17-wrapLinksSearch > ul > li.skiplinks_item.skiplinks_item--header-minicart.top-cart.has-items > a").to.have.value.that.equals("1");
};

this.goTobagandCheckout= function(){
browser
.click("#topCartContent > div > div.actions > a > span > span")
browser.assert.containsText("#topCartContent > div > div.actions > a > span > span", "go to bag & checkout");

};

this.proceedCheckout=  function(){
    browser
    .click("#btn-proceed-checkout > span > span")
    browser.assert.containsText("#btn-proceed-checkout > span > span", "Proceed to Checkout")
    .waitForElementVisible("body",2000)
    
    };

this.checkoutPage=function(){
    browser
    .waitForElementVisible("body",2000)
    browser.assert.containsText("#top > div.page-title > h2", "CHECKOUT / Welcome");
    };

    return this;
}