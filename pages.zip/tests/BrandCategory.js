/*
Given I am on the homepage
When I select brand category from the header
Then I should see the list of brands
And I select DOLCE & GABBANA brand from the list
Then I should see the list of products from DOLCE & GABBANA


to run this test = node nightwatch -e chrome -a Brand
*/


var utils=require("../pages/utils");
module.exports={
    "@tags":["Brand"],
    before:function(browser){
        utils(browser).openBrowser();
    },

"Select Brand Category from the header":function(browser){
utils(browser).selectbrand();
utils(browser).brandHeader();
},

"select DOLCE & GABBANA brand from the list":function(browser){
utils(browser).DGbrand();
},

    after:function(browser){
        browser.pause(5000);
        browser.end();
    }
}