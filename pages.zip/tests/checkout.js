/*Given I select men category from the header
And I am on PDP
When I select any colour and size for the chosen men category
And I add the product to the bag
Then I can see the bag with single item
And I click 'Proceed to Checkout'
Then I should be on checkout page

to run this test = node nightwatch -e chrome -a Men
*/

var utils=require("../pages/utils");
module.exports={
    "@tags":["Men"],
    before:function(browser){
        utils(browser).openBrowser();
       
    },
    "Given I Select Men Category from the header":function(browser){
        utils(browser).MenCategory();
        
        },
        "And I select Shoecolor":function(browser){
            utils(browser).shoecolor();
            
            },

           

        "And I am on PDP":function(browser){
            utils(browser).pdp();
            },

            "When I select any colour and size for the chosen men category":function(browser){
                utils(browser).selectShoe();
                
                
                },
                
                   "When I select any size for the chosen men category":function(browser){
                       utils(browser).selectSize();
                        
                        
                        },
                "And I add the product to the bag":function(browser){
                    utils(browser).addToBag ();
                    
                    
                    },
                    "Then I can see the bag with single item":function(browser){
                        utils(browser).myBag();
                        
                        },
                        "And I click 'Proceed to Checkout'":function(browser){
                            utils(browser).goTobagandCheckout()
                            utils(browser).proceedCheckout();
                            
                            },
                            "Then I should be on checkout page":function(browser){
                                utils(browser).goTobagandCheckout();
                               
                                
                                },

        after:function(browser){
           // browser.pause(5000);
            //browser.end();
        }
    
}